package com.mkyong.android;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class MyAndroidAppActivity extends Activity {

	private static final String TAG = "DataLabeling";
	Button btnChangeImage;
	Button btnReading;
	Button btnNotReading;
	ImageView image;
	List<String> filenames = new ArrayList<String>(); 
	String filename;
	String dataUnderLabeling;
	Map<String, Integer> DataWithLabels = new HashMap<String, Integer>();
	
	int i=0;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		addListenersOnButtons();
		
		listFiles("/dataPictures");

	}
	
	

	public void addListenersOnButtons() {

		image = (ImageView) findViewById(R.id.imageView1);

		btnChangeImage = (Button) findViewById(R.id.btnChangeImage);
		btnChangeImage.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				
				saveMapToCsv();
				

			}

		});
		
		btnReading=(Button) findViewById(R.id.btnReading);
				btnReading.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View arg0) {
						DataWithLabels.remove(dataUnderLabeling);
						DataWithLabels.put(dataUnderLabeling, 1);
						displayNextPicture();
						
						

					}

				});
				
			btnNotReading=(Button) findViewById(R.id.btnNotReading);
			btnNotReading.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View arg0) {
					DataWithLabels.remove(dataUnderLabeling);
					DataWithLabels.put(dataUnderLabeling, 0);
					displayNextPicture();	
					
						

					}

				});

	}

	
	public static Bitmap RotateBitmap(Bitmap source, float angle)
	{
	      Matrix matrix = new Matrix();
	      matrix.postRotate(angle);
	      return Bitmap.createBitmap(source, 0, 0, source.getWidth(), source.getHeight(), matrix, true);
	}
	
	public void listFiles(String directory){
		String path = Environment.getExternalStorageDirectory().toString()+directory;
		Log.d("Files", "Path: " + path);
		File f = new File(path);        
		File file[] = f.listFiles();
		Log.d("Files", "Size: "+ file.length);
		for (int i=0; i < file.length; i++)
		{
			filenames.add(file[i].getName());
		    Log.d("Files", "FileName:" + file[i].getName());
		}

	}
	
	public void saveMapToCsv(){
		
		java.util.Date date= new java.util.Date();
		String timestamp = new Timestamp(date.getTime()).toString();
		timestamp=timestamp.replace(" ", "_");
		timestamp=timestamp.replace(".", "_");
		timestamp=timestamp.replace(":", "_");
		timestamp=timestamp.replace("-", "_");
		
		File csvFile=new File("/sdcard/"+"datalabels"+timestamp+".csv");
		
		try {
			
			FileWriter writer = new FileWriter(csvFile);
			Iterator it = DataWithLabels.entrySet().iterator();
			while (it.hasNext()) {
			    Map.Entry pairs = (Map.Entry)it.next();
			    Log.d(TAG, String.valueOf(pairs.getKey()) + " = " + pairs.getValue());
			    
//			    writer.append(pairs.getKey().toString());
			    writer.append(String.valueOf(pairs.getKey()));
			    writer.append(',');
			    
//			    writer.append( pairs.getValue().toString());
			    writer.append( String.valueOf(pairs.getValue()));
			    writer.append('\n');
			    it.remove(); // avoids a ConcurrentModificationException
			}
			writer.flush();
			writer.close();
			Toast.makeText(this, "data saved to file", Toast.LENGTH_LONG);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void displayNextPicture(){
		if (i<filenames.size()){
			filename=filenames.get(i);
			Bitmap bmp = BitmapFactory.decodeFile("/sdcard/dataPictures/"+filename);
			
			bmp=RotateBitmap(bmp, 90);
			image.setImageBitmap(bmp);
			dataUnderLabeling=filename.substring(0, filename.length()-4);
			
			i+=1;
			
		}
	}
}