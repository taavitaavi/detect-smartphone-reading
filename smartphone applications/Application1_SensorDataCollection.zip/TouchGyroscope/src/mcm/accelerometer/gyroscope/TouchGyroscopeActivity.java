package mcm.accelerometer.gyroscope;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;

import mcm.client.rest.HttpManager;
import android.app.ActionBar;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Toast;

/*public class TouchGyroscopeActivity extends Activity {
    /** Called when the activity is first created. */
   /* @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
}*/

public class TouchGyroscopeActivity extends Activity implements AccelerometerListener, android.view.View.OnClickListener {

	private static final String TAG = "touchGyroscope";
	
	private static final boolean D = true;
	
	// Message types sent from the BluetoothChatService Handler
    
    public static final int MESSAGE_READ = 2;
    public static final int MESSAGE_WRITE = 3;
    public static final int MESSAGE_DEVICE_NAME = 4;
    public static final int MESSAGE_TOAST = 5;
    public static final int MESSAGE_STATE_CHANGE = 6;
    
 // Key names received from the BluetoothChatService Handler
    public static final String DEVICE_NAME = "device_name";
    public static final String TOAST = "toast";

    // Intent request codes
    private static final int REQUEST_CONNECT_DEVICE_SECURE = 1;
    private static final int REQUEST_CONNECT_DEVICE_INSECURE = 2;
    private static final int REQUEST_ENABLE_BT = 3;
    
    // Name of the connected device
    private String mConnectedDeviceName = null;
    // Array adapter for the conversation thread
    private ArrayAdapter<String> mConversationArrayAdapter;
    // String buffer for outgoing messages
    private StringBuffer mOutStringBuffer;
    // Local Bluetooth adapter
    private BluetoothAdapter mBluetoothAdapter = null;
    // Member object for the chat services
    private BluetoothChatService mChatService = null;
    
    
//  private DrawView dv;
	public static boolean SendBTData=false;
	public static boolean BTConnected=false;
	
//	public static TextView tv_acc;
  
  private StringBuilder localStringBuilder; 
  
  private HttpManager httpManager = HttpManager.getInstance();
  
  private AccelerometerDatabase DbMotion;
  private double px, py, pz;
  private double gx, gy, gz;
  private double [ ] sensorReadings={px,py,pz,gx,gy,gz};
  public static double[][] testSampleArray = new double[1][];
  private int threadCounter=0;
  private QueueOperator queueOperator=new QueueOperator(5, sensorReadings);
  
private double[][] Theta1=Predictor.readCsvToDoubleArray("/sdcard/Theta1.csv");
private double[][] Theta2=Predictor.readCsvToDoubleArray("/sdcard/Theta2.csv");

  public long lastTouch=0;
  public long timeSinceLastTouch=0;  
  private int readingDelay=1000;
  
  private boolean finishThread = false;
  
  private String actualUrl;
  
  private Button favorites;
  private Button mSendButton;
  private ImageView image;
//  private Paint paint = new Paint();
  
  private static Context CONTEXT;
  private WebView contenedor;
  private SensorEventListener lis = new SensorEventListener()
  
  {
    public void onAccuracyChanged(Sensor paramSensor, int paramInt)
    {
    }

    public void onSensorChanged(SensorEvent paramSensorEvent)
    {
      localStringBuilder = new StringBuilder();
      for (int i = 0; ; i++)
      {
        if (i >= paramSensorEvent.values.length)
        {
//          ((TextView)TouchGyroscopeActivity.this.findViewById(R.id.textView1)).setText(localStringBuilder.toString());
//          if (TouchGyroscopeActivity.this.dv != null)
//          {
        	float f1 = paramSensorEvent.values[2];
            float f2 = paramSensorEvent.values[1];
        	float f3 = paramSensorEvent.values[0];
//            TouchGyroscopeActivity.this.dv.moveX(-5.0F * f2);
//            TouchGyroscopeActivity.this.dv.moveY(-7.0F * f3);
//            TouchGyroscopeActivity.this.dv.invalidate();
            gx = f2;
        	gy = f3;
        	gz = f1;
//          }
          return;
        }
        if (i > 0)
          localStringBuilder.append("\n");
        float[] arrayOfFloat = paramSensorEvent.values;
        float f1 = (int)(24.0F * paramSensorEvent.values[i]) / 24.0F;
        arrayOfFloat[i] = f1;
        localStringBuilder.append(f1);
      }
    }
  };

  private void register()
  {
    SensorManager localSensorManager = (SensorManager)getSystemService("sensor");
    localSensorManager.registerListener(this.lis, localSensorManager.getDefaultSensor(4), 1);
    Log.d("GyroTest", "--SENSORS--");
    Iterator localIterator = localSensorManager.getSensorList(-1).iterator();
    while (true)
    {
      if (!localIterator.hasNext())
        return;
      Log.d("GyroTest", ((Sensor)localIterator.next()).getName());
    }
  }

  private void unregister()
  {
    ((SensorManager)getSystemService("sensor")).unregisterListener(this.lis);
  }

  @Override
  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(R.layout.main);
    
 // Get local Bluetooth adapter
    mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
    
 // If the adapter is null, then Bluetooth is not supported
    if (mBluetoothAdapter == null) {
        Toast.makeText(this, "Bluetooth is not available", Toast.LENGTH_LONG).show();
        finish();
        return;
    }

    
    CONTEXT = this;
    DbMotion = new AccelerometerDatabase(this);
    
    initializacionWebView();
    
    FrameLayout localFrameLayout = (FrameLayout)findViewById(R.id.frameLayout1);
//    this.dv = new DrawView(this);
//    localFrameLayout.addView(this.dv);
    
    collectInformation(); //collect gyroscope and accelerometer data
    
//    tv_acc = (TextView)findViewById(R.id.textView4);
    
    favorites = (Button) findViewById(R.id.button1);
    favorites.setOnClickListener(this);
    
    
    
    contenedor.setWebViewClient(new WebViewClient() {
		
		@Override
		public boolean shouldOverrideUrlLoading(WebView view, String url) {
			
			// appendToFile(url);
			actualUrl = url;
			view.loadUrl("http://www.google.com");

			return true;
		}
	});
  }

  protected void onStart()
  {
    super.onStart();
    
 // If BT is not on, request that it be enabled.
    // setupChat() will then be called during onActivityResult
    if (!mBluetoothAdapter.isEnabled()) {
        Intent enableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
        startActivityForResult(enableIntent, REQUEST_ENABLE_BT);
    // Otherwise, setup the chat session
    } else {
        if (mChatService == null) setupChat();
    }
  }

protected void onPause()
  {
    super.onPause();
    
	unregister();
    finishThread = true;
	finish();
    
	
  }

  protected void onResume()
  {
    super.onResume();
    register();
    if (AccelerometerManager.isSupported()) {
        AccelerometerManager.startListening(this);
    }
    // Performing this check in onResume() covers the case in which BT was
    // not enabled during onStart(), so we were paused to enable it...
    // onResume() will be called when ACTION_REQUEST_ENABLE activity returns.
    if (mChatService != null) {
        // Only if the state is STATE_NONE, do we know that we haven't started already
        if (mChatService.getState() == BluetoothChatService.STATE_NONE) {
          // Start the Bluetooth chat services
          mChatService.start();
        }
    }
  }

  protected void onDestroy()
  {
    super.onDestroy();
    if (AccelerometerManager.isListening()) {
        AccelerometerManager.stopListening();
    }
    finishThread = true;
    
    // Stop the Bluetooth chat services
    if (mChatService != null) mChatService.stop();
  }
  
  public void onActivityResult(int requestCode, int resultCode, Intent data) {
      if(D) Log.d(TAG, "onActivityResult " + resultCode);
      switch (requestCode) {
      case REQUEST_CONNECT_DEVICE_SECURE:
          // When DeviceListActivity returns with a device to connect
          if (resultCode == Activity.RESULT_OK) {
              connectDevice(data, true);
          }
          break;
      case REQUEST_CONNECT_DEVICE_INSECURE:
          // When DeviceListActivity returns with a device to connect
          if (resultCode == Activity.RESULT_OK) {
              connectDevice(data, false);
          }
          break;
      case REQUEST_ENABLE_BT:
          // When the request to enable Bluetooth returns
          if (resultCode == Activity.RESULT_OK) {
              // Bluetooth is now enabled, so set up a chat session
              setupChat();
          } else {
              // User did not enable Bluetooth or an error occurred
              Log.d(TAG, "BT not enabled");
              Toast.makeText(this, R.string.bt_not_enabled_leaving, Toast.LENGTH_SHORT).show();
              finish();
          }
      }
  }

public static Context getContext() {
      return CONTEXT;
  }

public void onAccelerationChanged(float x, float y, float z) {
//	 TODO Auto-generated method stub	
////	tv_acc.setText("X :"+ String.valueOf(x) +"\n"+
//			   "Y :"+ String.valueOf(y) +"\n"+
//			   "Z :"+ String.valueOf(z));
	px = x;
	py = y;
	pz = z;
	
}

public void onShake(float force) {
	// TODO Auto-generated method stub
	Toast.makeText(this, "Phone shaked : " + force, 1000).show();
	
}

@Override
public boolean onKeyDown(int keyCode, KeyEvent event) {
	if ((keyCode == KeyEvent.KEYCODE_BACK) && contenedor.canGoBack()) {
		contenedor.goBack();
		return true;
	}
	return super.onKeyDown(keyCode, event);
}

private void createBitMap(int color) {
    // Create a mutable bitmap
    Bitmap bitMap = Bitmap.createBitmap(100, 100, Bitmap.Config.ARGB_8888);

    bitMap = bitMap.copy(bitMap.getConfig(), true);
    // Construct a canvas with the specified bitmap to draw into
    Canvas canvas = new Canvas(bitMap);
    // Create a new paint with default settings.
    Paint paint=new Paint();
    // smooths out the edges of what is being drawn
    paint.setAntiAlias(true);
    // set color
    paint.setColor(color);
    // set style
    paint.setStyle(Paint.Style.FILL);
    // set stroke
    paint.setStrokeWidth(4.5f);
    // draw circle with radius 30
    canvas.drawCircle(50, 50, 30, paint);
    // set on ImageView or any other view 
    image.setImageBitmap(bitMap);

}
 

  public void initializacionWebView() {
		// Initialization of the WebView
		contenedor = (WebView) findViewById(R.id.webView1); 
		contenedor.getSettings().setJavaScriptEnabled(true);
		contenedor.getSettings()
				.setJavaScriptCanOpenWindowsAutomatically(false);
//		contenedor.getSettings().setPluginsEnabled(false);
		contenedor.getSettings().setSupportMultipleWindows(false);
		contenedor.getSettings().setSupportZoom(false);
		contenedor.getSettings().setJavaScriptEnabled(true);
		contenedor.setVerticalScrollBarEnabled(true);
		contenedor.setHorizontalScrollBarEnabled(true);
		contenedor.loadUrl("https://sites.google.com/site/taavitaavi/");
		actualUrl="https://sites.google.com/site/taavitaavi/";
		contenedor.canGoBack();
		
		
		contenedor.setOnTouchListener(new View.OnTouchListener() {
		    
		    public boolean onTouch(View view, MotionEvent event) {
		    	
		    	
		    	int i = event.getAction();

		        switch(i){

		        case MotionEvent.ACTION_DOWN:
		            //When your finger touches the screen
		        	Log.d(TAG, "finger down");
		        	lastTouch = System.currentTimeMillis();
//		        	tv_acc.setText("down");

		            break;

		        case MotionEvent.ACTION_UP:
		            //When your finger stop touching the screen
		        	Log.d(TAG, "finger up");
//		        	tv_acc.setText("up");

		            break;

		        case MotionEvent.ACTION_MOVE:
		        	Log.d(TAG, "finger move");
		            //When your finger moves around the screen
		        	
		        	
//		        	tv_acc.setText("move"+String.valueOf(lastTouch));
		        	
		        	
		            break;
		        }
		        return false;
		    }
		});
		

	}
  
  public void collectInformation() {
	  
		Thread t = new Thread() {
			public void run() {
				image=(ImageView)findViewById(R.id.imageView1);

				while (!finishThread) {
					
					timeSinceLastTouch =System.currentTimeMillis() -lastTouch;
//					tv_acc.setText(String.valueOf(msSinceLastTouch));
//					if(BTConnected){
//						String message=String.valueOf(lastTouch)+"\n";
//						BluetoothConnectionActivity.connectedThread.write(message.getBytes());
//
//					}
					
//					String message="mesage";
//					sendMessage(message);
					
					
						double [] sensorReadings1={px,py,pz,gx,gy,gz};
						double[] testSample=queueOperator.RunningStandardDeviation(sensorReadings1);
						
//						Log.d(TAG,"SensorReadings: "+Arrays.toString(sensorReadings1));
//						Log.d(TAG,"testSample: "+Arrays.toString(testSample));
						testSampleArray[0]=testSample;
						
						final int[] readingPrediction=Predictor.predict(Theta1, Theta2, testSampleArray);
						
						
						runOnUiThread(new Runnable() {
						     public void run() {

						    	 if (readingPrediction[0]==1) {
										createBitMap(Color.GREEN);
										
									}
									else{
										createBitMap(Color.RED);
									}

						    }
						});
						Log.d(TAG,"readingprediction: "+Arrays.toString(readingPrediction));
					
					
					messageHandler.sendMessage(Message
							.obtain(messageHandler, 1));
					
					

					//  input delayed by readingDelay
					try {
						Thread.sleep(readingDelay);

					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}

			
		};

		t.start();
	}

	Handler messageHandler = new Handler() {

		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {
			
			case MESSAGE_STATE_CHANGE:
                if(D) Log.i(TAG, "MESSAGE_STATE_CHANGE: " + msg.arg1);
                switch (msg.arg1) {
                case BluetoothChatService.STATE_CONNECTED:
                    setStatus(getString(R.string.title_connected_to, mConnectedDeviceName));
                    mConversationArrayAdapter.clear();
                    break;
                case BluetoothChatService.STATE_CONNECTING:
                    setStatus(R.string.title_connecting);
                    break;
                case BluetoothChatService.STATE_LISTEN:
                case BluetoothChatService.STATE_NONE:
                    setStatus(R.string.title_not_connected);
                    break;
                }
                break;
                
            case MESSAGE_WRITE:
                byte[] writeBuf = (byte[]) msg.obj;
                // construct a string from the buffer
                String writeMessage = new String(writeBuf);
                mConversationArrayAdapter.add("Me:  " + writeMessage);
                break;
            case MESSAGE_READ:
                byte[] readBuf = (byte[]) msg.obj;
                // construct a string from the valid bytes in the buffer
                String readMessage = new String(readBuf, 0, msg.arg1);
                mConversationArrayAdapter.add(mConnectedDeviceName+":  " + readMessage);
                break;
            case MESSAGE_DEVICE_NAME:
                // save the connected device's name
                mConnectedDeviceName = msg.getData().getString(DEVICE_NAME);
                Toast.makeText(getApplicationContext(), "Connected to "
                               + mConnectedDeviceName, Toast.LENGTH_SHORT).show();
                break;
            case MESSAGE_TOAST:
                Toast.makeText(getApplicationContext(), msg.getData().getString(TOAST),
                               Toast.LENGTH_SHORT).show();
                break;
			case 1:
				DbMotion.open();
				
				// calendar.getTime().toString()
				// DbMotion.createAccelerometerEntry(calendar.getTimeInMillis(),actualUrl,px,
				// py, pz);
				//DbMotion.createAccelerometerEntry(calendar.getTime().getSeconds(), actualUrl, px / 10, py / 10, pz / 10);
				java.util.Date date= new java.util.Date();
				String timestamp = new Timestamp(date.getTime()).toString();

				timestamp=timestamp.replace(" ", "_");
				timestamp=timestamp.replace(".", "_");
				timestamp=timestamp.replace(":", "_");
				timestamp=timestamp.replace("-", "_");

				if(BTConnected && SendBTData){
					BluetoothChat.sendMessage(timestamp);
					Log.d(TAG, "timestamp:"+timestamp);
				}
				
				
				DbMotion.createAccelerometerEntry(timestamp, actualUrl, px, py, pz,gx,gy,gz,timeSinceLastTouch);
				
				DbMotion.close();
				break;
			}
			
		}

	};

	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch(v.getId()){
		case R.id.button1:
			
			        //Upload to the cloud and Processing invokation
					cloneDatabase base = new cloneDatabase();
					try {
						if (base.fileToCopy()){
							base.copyDataBase();
						}
					} catch (IOException e) {
						e.printStackTrace();
					}
				  

////					File file = new File(base.getDataBasePath());
//
//					File file = new File(base.getDataBasePath());

//					try {
//						httpManager.UploadFile(file,Utilities.AMAZON_S3);
//					} catch (IOException e) {
//						// TODO Auto-generated catch block
//						e.printStackTrace();
//					}
					
					/*ArrayList<NameValuePair> parameters = new ArrayList<NameValuePair>();
					parameters.add(new BasicNameValuePair(Utilities.SECRETKEY_PARAM, Utilities.secretKey));
					parameters.add(new BasicNameValuePair(Utilities.IDKEY_PARAM,Utilities.idKey));	
					parameters.add(new BasicNameValuePair(Utilities.IMAGE_PARAM, Utilities.image));
					
					try {
						httpManager.postRequest(Utilities.client, parameters);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}*/
					
					break;
		}
		
	}

	public void connectBlueTooth(View v){
		Intent intent = new Intent(this, BluetoothChat.class);
		startActivity(intent);
		
	}

	private void setupChat() {
		// TODO Auto-generated method stub
		Log.d(TAG, "setupChat()");
		
        mSendButton = (Button) findViewById(R.id.button_send);
        mSendButton.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                // Send a message using content of the edit text widget
                
                SendBTData=!SendBTData;
                if(BTConnected){
                	if(!SendBTData){
                    	mSendButton.setText("Start");
                    }
                    else{
                    	mSendButton.setText("Stop");
                    }
                	
                	
                	
                }
                
//                BluetoothChat.sendMessage(message);
            }
        });
		
		
	}


    private void ensureDiscoverable() {
        if(D) Log.d(TAG, "ensure discoverable");
        if (mBluetoothAdapter.getScanMode() !=
            BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE) {
            Intent discoverableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
            discoverableIntent.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300);
            startActivity(discoverableIntent);
        }
    }
    
    private final void setStatus(int resId) {
        final ActionBar actionBar = getActionBar();
        actionBar.setSubtitle(resId);
    }
    
    private final void setStatus(CharSequence subTitle) {
        final ActionBar actionBar = getActionBar();
        actionBar.setSubtitle(subTitle);
    }
    
    
    private void connectDevice(Intent data, boolean secure) {
        // Get the device MAC address
        String address = data.getExtras()
            .getString(DeviceListActivity.EXTRA_DEVICE_ADDRESS);
        // Get the BluetoothDevice object
        BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(address);
        // Attempt to connect to the device
        mChatService.connect(device, secure);
    }
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.option_menu, menu);
        return true;
    }
    
    public String getAssetPath(String filename){
    	File f = new File(getCacheDir()+filename);
    	  if (!f.exists()) try {

    	    InputStream is = getAssets().open(filename);
    	    int size = is.available();
    	    byte[] buffer = new byte[size];
    	    is.read(buffer);
    	    is.close();


    	    FileOutputStream fos = new FileOutputStream(f);
    	    fos.write(buffer);
    	    fos.close();
    	  } catch (Exception e) { throw new RuntimeException(e); }
    	  return f.getPath();
    }
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent serverIntent = null;
        switch (item.getItemId()) {
        case R.id.secure_connect_scan:
            // Launch the DeviceListActivity to see devices and do scan
            serverIntent = new Intent(this, DeviceListActivity.class);
            startActivityForResult(serverIntent, REQUEST_CONNECT_DEVICE_SECURE);
            return true;
        case R.id.insecure_connect_scan:
            // Launch the DeviceListActivity to see devices and do scan
            serverIntent = new Intent(this, DeviceListActivity.class);
            startActivityForResult(serverIntent, REQUEST_CONNECT_DEVICE_INSECURE);
            return true;
        case R.id.discoverable:
            // Ensure this device is discoverable by others
            ensureDiscoverable();
            return true;
        }
        return false;
    }

	
	

	
	
}

