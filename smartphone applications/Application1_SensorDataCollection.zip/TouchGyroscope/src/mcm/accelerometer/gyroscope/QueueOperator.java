package mcm.accelerometer.gyroscope;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;

import org.apache.commons.math3.stat.descriptive.moment.StandardDeviation;

public class QueueOperator {
	private int queuelength;
	private double[] variables;
	private ArrayList<Queue> queuesArray;
	

	public QueueOperator(int queuelength, double[] variables) {
		super();
		this.queuelength = queuelength;
		this.variables = variables;
		this.queuesArray = new ArrayList<Queue>(variables.length);

		for(int i = 0; i < variables.length; i++) {
			Queue<Double> Q=new LinkedList<Double>();
		     queuesArray.add(Q);
		}
		
	}

	public double[] RunningStandardDeviation(double[] sensorreadings) {
		double[] standarddeviations= new double[variables.length];
		
		int variable=0;
		for (Queue queue : queuesArray) {
			
			if (queue.size()<5) {
			queue.add(variables[variable]);
			standarddeviations[variable]=0.0;
			}
			else{
				queue.add(variables[variable]);
				queue.poll();
				double queueStdev=queueStandardDeviation(queue);
				standarddeviations[variable]=queueStdev;
		}
			
			variable++;
		}
		
        double[] concatenate = combine(sensorreadings, standarddeviations);



		return concatenate;
	}
	

	public static double[] combine(double[] a, double[] b){
        int length = a.length + b.length;
        double[] result = new double[length];
        System.arraycopy(a, 0, result, 0, a.length);
        System.arraycopy(b, 0, result, a.length, b.length);
        return result;
	}


	public static double queueStandardDeviation(Queue<Double> Q){
		
		Object[] arrayQ=Q.toArray();
        double[] queue=new double[arrayQ.length];
        for (int i = 0; i < arrayQ.length; i++) {
			queue[i]=new Double(arrayQ[i].toString());
		}
        StandardDeviation stdev= new StandardDeviation();
		return stdev.evaluate(queue);
		
	};

}
