package mcm.accelerometer.gyroscope;

import android.widget.TextView;

public class MessagePoster implements Runnable {

	private TextView textView;
	 private String message;
	 public MessagePoster(TextView textView, String message) {
	 this.textView = textView;
	 this.message = message;
	 }
	public void run() {
		// TODO Auto-generated method stub
		textView.setText(message);
	}

}
