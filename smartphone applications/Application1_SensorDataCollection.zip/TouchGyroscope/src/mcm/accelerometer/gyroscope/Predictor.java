package mcm.accelerometer.gyroscope;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.math3.linear.MatrixUtils;
import org.apache.commons.math3.linear.RealMatrix;

import android.content.res.AssetManager;
import au.com.bytecode.opencsv.CSVReader;

public class Predictor {
	public static double[] trainColumn;
//	public static void main(String[] args) {  
//		double[][] dInputandOutput=readCsvToDoubleArray("C:/Users/John/Dropbox/kool2/kool/01 Semester VIII/thesis/human-reading-activity-recognition-on-smartphones/data analysis/implementation of learning algorithms/neural network/mlclass-ex4/testSet.csv");
//		RealMatrix input= MatrixUtils.createRealMatrix(dInputandOutput);
//		trainColumn=input.getColumn(input.getColumnDimension()-1);
//		input=input.getSubMatrix(0, dInputandOutput.length-1, 0, dInputandOutput[0].length-2);
//		
//		double[][] dInput=input.getData();
//		double[][] dTheta1=readCsvToDoubleArray("C:/Users/John/Dropbox/kool2/kool/01 Semester VIII/thesis/human-reading-activity-recognition-on-smartphones/data analysis/implementation of learning algorithms/neural network/mlclass-ex4/Theta1.csv");
//		double[][] dTheta2=readCsvToDoubleArray("C:/Users/John/Dropbox/kool2/kool/01 Semester VIII/thesis/human-reading-activity-recognition-on-smartphones/data analysis/implementation of learning algorithms/neural network/mlclass-ex4/Theta2.csv");
//		int[] prediction=predict(dTheta1, dTheta2, dInput);
//		
//		
//	}
	public static double[][] readCsvToDoubleArray(String filename){
		List<String[]> strInput=readCsvToStrArray(filename);
		double[][] dInput=convertStringArrayToDoubleArray(strInput);
		return dInput;
		
	}
	public static double[][] convertStringArrayToDoubleArray(List<String[]> stringList){
		double[][] doubleArray = new double[stringList.size()][stringList.get(0).length];
		for (int rowIndex = 0; rowIndex < stringList.size(); rowIndex++) {
			String[] row=stringList.get(rowIndex);
			for (int columnIndex = 0; columnIndex < row.length; columnIndex++) {
//				System.out.println("Element"+rowIndex+":"+columnIndex+" is "+stringList.get(rowIndex)[columnIndex]);
				doubleArray[rowIndex][columnIndex]=Double.parseDouble(stringList.get(rowIndex)[columnIndex]);
			}			
		}
		
		return doubleArray;
	}
	public static List<String[]> readCsvToStrArray(String filename){
		CSVReader reader = null;
		
		
//		new File("file:///android_asset/helloworld.txt");
		try {
			reader = new CSVReader(new FileReader(filename));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<String[]> myEntries = null;
		try {
			myEntries = reader.readAll();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return myEntries;
	}
	
	


 	public static int[] predict(double[][] Theta1, double[][] Theta2, double[][] input){
 		int m=input.length;
 		int[] p= new int[m];
		int numLabels= Theta2.length;
		double[][] ones=ones(m, 1);
		double[][] onesAndInput=concatenateVertically(ones, input);
		RealMatrix onePlusInput= MatrixUtils.createRealMatrix(onesAndInput);
		RealMatrix mat1 = MatrixUtils.createRealMatrix(Theta1);
		RealMatrix m1=mat1.transpose();
		RealMatrix product1 = onePlusInput.multiply(m1);
		RealMatrix h1= sigmoid(product1);
		
		double[][] dh1=h1.getData();
		double[][] onesAndDh1=concatenateVertically(ones,dh1 );
		RealMatrix onePlush1= MatrixUtils.createRealMatrix(onesAndDh1);
		RealMatrix mat2 = MatrixUtils.createRealMatrix(Theta2);
		RealMatrix m2=mat2.transpose();
		RealMatrix product2 = onePlush1.multiply(m2);
		RealMatrix h2= sigmoid(product2);
		int[] accuracy=new int[h2.getRowDimension()];
		for (int row = 0; row < h2.getRowDimension(); row++) {
			
			int maxIndex = 0;
			for (int i = 0; i < h2.getRow(row).length; i++){
			   double newnumber = h2.getRow(row)[i];
			   
			   if ((newnumber > h2.getRow(row)[maxIndex])){
			   maxIndex = i;
			   
			  }

			}  
			// because of indexing we have to set 1 and 0 manually
			if(maxIndex==0){maxIndex=1;}
			else{maxIndex=0;}
			p[row]=maxIndex;
			
//			if(maxIndex==trainColumn[row]){
//				accuracy[row]=1;
//			}
//			else{
//				accuracy[row]=0;
//			}
//			System.out.println("maxIndex: "+maxIndex+" training:"+trainColumn[row]);

		}
//		
//		int sum = 0;
//
//		for (int i : accuracy){
//			sum += i;
//		}
//		    double accPercent=(1.0*sum/accuracy.length)*100;
//		System.out.println("Prediction Accuracy:"+accPercent);
		return p;
	}
	public static double sigmoid(double z){
		double g= 1.0/(1.0+Math.exp(-1*z));
		return g;
//		g = 1.0 ./ (1.0 + exp(-z));
		
	}
	public static RealMatrix sigmoid(RealMatrix z){
		for (int row = 0; row < z.getRowDimension(); row++) {
			for (int column = 0; column < z.getColumnDimension(); column++) {
				double g= sigmoid(z.getEntry(row, column));
				z.setEntry(row, column, g);
				
				
			}
			
		}
		
		return z;
	}
	public static double[][] ones(int rows, int columns){
		double[][] array = new double[rows][columns];
		for (double[] row: array){
			Arrays.fill(row, 1);		
		}
		return array;
	}
	
	public static double[] concat(double[] A, double[] B) {
		   int aLen = A.length;
		   int bLen = B.length;
		   double[] C= new double[aLen+bLen];
		   System.arraycopy(A, 0, C, 0, aLen);
		   System.arraycopy(B, 0, C, aLen, bLen);
		   return C;
		}
	
	public static double[][] concatenateVertically(double[][] a1,double[][] a2){
		
		double[][] result=null;

			result = new double[a1.length][a1[0].length+a2[0].length];
			
			for (int row = 0; row < a1.length; row++) {			
				result[row]=concat(a1[row],a2[row]);
				
			}
		
		return result;
		
	}
}
