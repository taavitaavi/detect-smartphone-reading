package mcm.accelerometer.gyroscope;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Timestamp;
import java.util.Calendar;

import android.os.Build;
import android.util.Log;



public class cloneDatabase {
	private static final String TAG = "CloneDatabase";

	private String outFileName;
	
	//Copy the Database from its default location
    public void copyDataBase() throws IOException{
		 
    	InputStream myInput = new FileInputStream("/data/data/mcm.accelerometer.gyroscope/databases/DBmotion");
    	
    	java.util.Date date= new java.util.Date();
		String timestamp = new Timestamp(date.getTime()).toString();

		timestamp=timestamp.replace(" ", "_");
		timestamp=timestamp.replace(".", "_");
		timestamp=timestamp.replace(":", "_");
		timestamp=timestamp.replace("-", "_");
		String deviceName=getDeviceName();
		
    	

    	this.outFileName = "/sdcard/DBmotion"+timestamp +deviceName+".sql";

//    	this.outFileName = "/sdcard/DBmotion"+timestamp +".sql";

    	
//    	this.outFileName = "/sdcard/DBmotion/DBmotion" + timestamp+".sql";

     	OutputStream myOutput = new FileOutputStream(outFileName);
     	byte[] buffer = new byte[1024];
    	int length;
    	while ((length = myInput.read(buffer))>0){
    		myOutput.write(buffer, 0, length);
    	}
     	myOutput.flush();
    	myOutput.close();
    	myInput.close();
    	
    	File borrar = new File("/data/data/mcm.accelerometer.gyroscope/databases/DBmotion");
    	borrar.delete();
 
    }
    
    public boolean fileToCopy(){
    	File check = new File("/data/data/mcm.accelerometer.gyroscope/databases/DBmotion");
    	if (check.exists()==true){
    		return true;
    	}else{
    		return false;
    	}
    }
    
    public String getDeviceName() {
    	
  	  String manufacturer = Build.MANUFACTURER;
  	  String model = Build.MODEL;
  	  if (model.startsWith(manufacturer)) {
  		  Log.d(TAG,model);
  	    return model;
  	  } else {
  		  Log.d(TAG,manufacturer + " " + model );
  	    return manufacturer + " " + model;
  	    
  	  }
  	}

    public String getDataBasePath(){
    	return this.outFileName;
    }
	
}
