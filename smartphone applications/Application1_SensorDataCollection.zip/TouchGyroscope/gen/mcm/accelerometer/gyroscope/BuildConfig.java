/** Automatically generated file. DO NOT MODIFY */
package mcm.accelerometer.gyroscope;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}